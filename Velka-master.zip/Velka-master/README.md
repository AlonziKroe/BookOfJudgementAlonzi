# Velka
Velka themed cogs for Red on Discord

The BookOfJudgement cog allows users to award each other points and view leaderboards. It also handles co-op requests.
Much of the code was taken from https://github.com/tekulvw/Squid-Plugins/tree/master/karma

Welcome cog sends random welcome messages to new users. It also sends a custom DM.
Slightly modified version of https://github.com/irdumbs/Dumb-Cogs/tree/master/welcome